<?php
defined('BASEPATH') or exit('No direct script access allowed');

class KelolaAbsensi_admin extends CI_Controller
{
    var $module_js = ['kelola_absen'];
    var $app_data = [];

    public function __construct()
    {
        parent::__construct();
        $this->_init();
    }

    private function _init()
    {
        $this->app_data['module_js'] = $this->module_js;
    }

    public function index()
    {
        $this->app_data['select'] = $this->data->get_all('tb_tentor')->result(); 
        $this->load->view('header_pm');
        $this->load->view('view_absen', $this->app_data);
        $this->load->view('footer');
        $this->load->view('js-custom', $this->app_data);
    }

    public function get_data()
    {
        $query = [
            'select' => 'a.id_absensi, a.tgl_absen, a.materi, a.bukti, b.nama',
            'from' => 'tb_absen a',
            'join' => [
                'tb_tentor b, b.id_tentor = a.id_tentor'
            ]
        ];
        $result = $this->data->get($query)->result();
        echo json_encode($result);
        // $result = $this->data->get_all('tb_absen')->result();
        // echo json_encode($result);
    }

    public function get_data_id()
    {
        $id = $this->input->post('id_absensi');
        // $query = [
        //     'select' => 'a.id_member, a.nama, a.alamat, a.asal_sekolah, a.kelas, a.telepon, a.email, b.username',
        //     'from' => 'tb_member a',
        //     'join' => [
        //         'tb_user b, b.id.user = a.id_user'
        //     ],
        //     'where' => [
        //         'a.id_member' => $id
        //     ]
        // ];
        $where = array('id_absensi' => $id);
        $result = $this->data->find('tb_absen', $where)->result();
        echo json_encode($result);
    }


    public function insert_data()
    {
        $this->form_validation->set_rules('tgl_absen', 'tgl_absen', 'required|trim');
        $this->form_validation->set_rules('materi', 'materi', 'required|trim');

        if ($this->form_validation->run() == false) {
            $response['errors'] = $this->form_validation->error_array();
            if (empty($_FILES['bukti']['name'])) {
                $response['errors']['bukti'] = "Bukti gambar harus diupload";
            }
            if (empty($this->input->post('id_tentor'))) {
                $response['errors']['id_tentor'] = "Tentor harus dipilih";
            }
        } else {
            $tgl_absensi = $this->input->post('tgl_absensi');
            $materi = $this->input->post('materi');

            if (empty($_FILES['bukti']['name'])) {
                $response['errors']['bukti'] = "Bukti gambar harus diupload";
            }
            if (empty($this->input->post('id_tentor'))) {
                $response['errors']['id_tentor'] = "Tentor harus dipilih";
            } else {
                $data = array(
                    'id_tentor' => $id_tentor = $this->input->post('id_tentor'),
                    'tgl_absen' => $tgl_absensi,
                    'materi' => $materi,
                );

                if (!empty($_FILES['bukti']['name'])) {
                    $currentDateTime = date('Y-m-d_H-i-s');
                    $config['upload_path'] = './assets/file/';
                    $config['allowed_types'] = 'gif|jpg|jpeg|png';
                    $config['file_name'] = 'Bukti_' . $currentDateTime;
                    $config['max_size'] = 2048;

                    $this->load->library('upload', $config);

                    if (!$this->upload->do_upload('bukti')) {
                        $response['errors']['bukti'] = strip_tags($this->upload->display_errors());
                    } else {
                        $uploaded_data = $this->upload->data();
                        $data['bukti'] = $uploaded_data['file_name'];

                        $this->data->insert('tb_absen', $data);
                        $response['success'] = "Data berhasil ditambahkan";
                    }
                } else {
                    $response['errors']['bukti'] = "Foto harus diupload";
                }

            }
        }
        echo json_encode($response);
    }

    public function delete_data()
{
    $id = $this->input->post('id_absensi');
    $where = array('id_absensi' => $id);
    $data_absen = $this->data->find('tb_absen', $where)->row_array();
    $deleted = $this->data->delete('tb_absen', $where);

    if ($deleted) {
        $file_path = './assets/file/' . $data_absen['bukti'];

        // Cek apakah $bukti bukan direktori
        if (!is_dir($file_path) && file_exists($file_path)) {
            unlink($file_path);
        }

        $response['success'] = "Data berhasil dihapus";
    } else {
        $response['error'] = "Gagal menghapus data";
    }

    echo json_encode($response);
}

public function export_pdf()
	{
        $query = [
            'select' => 'a.id_absensi, a.tgl_absen, a.materi, a.bukti, b.nama',
            'from' => 'tb_absen a',
            'join' => [
                'tb_tentor b, b.id_tentor = a.id_tentor'
            ]
        ];
        $data['absen'] = $this->data->get($query)->result();
		$this->load->library('pdf');
		$this->pdf->setPaper('A4', 'potrait');
		$this->pdf->filename = "laporan-data-absen.pdf";
		$this->pdf->load_view('laporan_absen', $data);
	}

    // public function delete_data() {
    //     $id = $this->input->post('id_absensi');
    //     $where = array('id_absensi' => $id);
    //     $bukti = $this->data->get_file_name('tb_absen', $where, 'bukti');
    //     $deleted = $this->data->delete('tb_absen', $where);
    
    //     if ($deleted) {
    //         $file_path = './assets/file/' . $bukti;
    
    //         // Cek apakah $bukti bukan direktori
    //         if (!is_dir($file_path) && file_exists($file_path)) {
    //             unlink($file_path);
    //         }
    
    //         $response['success'] = "Data berhasil dihapus";
    //     } else {
    //         $response['error'] = "Gagal menghapus data";
    //     }
    
    //     echo json_encode($response);
    // }

    // public function edit_data()
    // {
    //     $this->form_validation->set_rules('id_murid', 'id_murid', 'required|trim');
    //     $this->form_validation->set_rules('nama', 'nama', 'required|trim');
    //     $this->form_validation->set_rules('alamat', 'alamat', 'required|trim');
    //     $this->form_validation->set_rules('asal_sekolah', 'asal_sekolah', 'required|trim');
    //     $this->form_validation->set_rules('kelas', 'kelas', 'required|trim');
    //     $this->form_validation->set_rules('telepon', 'telepon', 'required|trim');
    //     $this->form_validation->set_rules('email', 'email', 'required|trim');

    //     if ($this->form_validation->run() == false) {
    //         $response['errors'] = $this->form_validation->error_array();
    //         if (empty($this->input->post('id_user'))) {
    //             $response['errors']['id_user'] = "ID User harus dipilih";
    //         }
    //     } else {
    //         $id = $this->input->post('id_murid');
    //         $nama = $this->input->post('nama');
    //         $alamat = $this->input->post('alamat');
    //         $asal_sekolah = $this->input->post('asal_sekolah');
    //         $kelas = $this->input->post('kelas');
    //         $telepon = $this->input->post('telepon');
    //         $email = $this->input->post('email');

    //         if (empty($this->input->post('id_user'))) {
    //             $response['errors']['id_user'] = "id user harus dipilih";
    //         } else {
    //             $data = array(
    //                 'id_murid' => $id,
    //                 'id_user' => $id_user = $this->input->post('id_user'),
    //                 'nama' => $nama,
    //                 'alamat' => $alamat,
    //                 'asal_sekolah' => $asal_sekolah,
    //                 'kelas' => $kelas,
    //                 'telepon' => $telepon,
    //                 'email' => $email,
    //             );

    //             $where = array('id_murid' => $id);
    //             $this->data->update('tb_murid', $where, $data);
    //             $response['success'] = "Data berhasil diedit";
    //         }
    //     }
    //     echo json_encode($response);
    // }
 } 