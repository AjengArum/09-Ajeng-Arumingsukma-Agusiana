<?php

use chriskacerguis\RestServer\RestController;

require APPPATH . '/libraries/RestController.php';

class Manage_all extends RestController
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('All_model', 'all');
        $this->load->helper(['url', 'file']);
        $this->load->library('upload');
    }

    public function index_get()
    {
        $this->response($this->all->get_data(), RestController::HTTP_OK);
    }

    // public function login_post()
    // {
    //     $email = $this->post('email');
    //     $password = $this->post('password');
    //     $this->response($this->all->login($email, $password), RestController::HTTP_OK);
    // }

    public function get_pembayaran_get()
    {
        $this->response($this->all->get_pembayaran(), RestController::HTTP_OK);
    }

    public function get_layanan_get()
    {
        $this->response($this->all->get_layanan(), RestController::HTTP_OK);
    }

    public function get_rekap_get()
    {
        $this->response($this->all->get_rekap(), RestController::HTTP_OK);
    }

    // public function get_produk_terbaru_get()
    // {
    //     $this->response($this->all->get_produk_terbaru(), RestController::HTTP_OK);
    // }

    // public function get_produk_terlaris_get()
    // {
    //     $this->response($this->all->get_produk_terlaris(), RestController::HTTP_OK);
    // }

    // public function get_category_get()
    // {
    //     $this->response($this->all->get_category(), RestController::HTTP_OK);
    // }

    // public function get_detail_produk_get($id)
    // {
    //     $this->response($this->all->get_detail_produk($id), RestController::HTTP_OK);
    // }

    // public function insert_keranjang_post()
    // {
    //     $product_id = $this->post('product_id');
    //     $user_id = $this->post('user_id');
    //     $qty = $this->post('qty');
    //     $price = $this->post('price');
    //     $this->response($this->all->insert_keranjang($product_id, $user_id, $qty, $price), RestController::HTTP_OK);
    // }

    // public function insert_murid_post()
    // {
    //    // $id_murid = $this->post('id_murid');
    //     $id_user = $this->post('id_user');
    //     $id_layanan = $this->post('id_layanan');
    //     $asal_sekolah = $this->post('asal_sekolah');
    //     $kelas = $this->post('kelas');
    //     $this->response($this->all->insert_murid($id_user, $id_layanan, $asal_sekolah, $kelas), RestController::HTTP_OK);
    // }

    public function insert_murid_post()
{
    $id_user = $this->input->get('id_user');
    $id_layanan = $this->input->get('id_layanan');
    $nama = $this->input->get('nama');
    $asal_sekolah = $this->input->get('asal_sekolah');
    $kelas = $this->input->get('kelas');
    $result = $this->all->insert_murid($id_user, $id_layanan, $nama, $asal_sekolah, $kelas);

    if ($result["success"]) {
        $this->response($result, RestController::HTTP_OK);
    } else {
        $this->response($result, RestController::HTTP_INTERNAL_SERVER_ERROR);
    }
}

public function insert_user_post()
{
    $ID = $this->input->get('ID');
    $id_akses = $this->input->get('id_akses');
    $username = $this->input->get('username');
    $alamat = $this->input->get('alamat');
    $telepon = $this->input->get('telepon');
    $email = $this->input->get('email');
    $password = $this->input->get('password');
    $result = $this->all->insert_user($ID, $id_akses, $username, $alamat, $telepon, $email, $password);

    if ($result["success"]) {
        $this->response($result, RestController::HTTP_OK);
    } else {
        $this->response($result, RestController::HTTP_INTERNAL_SERVER_ERROR);
    }
}

// URL yang benar:
// http://localhost/TA_1/api/Manage_all/insert_murid_post



    // public function get_keranjang_get()
    // {
    //     $this->response($this->all->get_keranjang(), RestController::HTTP_OK);
    // }

    // public function get_mitra_get()
    // {
    //     $this->response($this->all->get_mitra(), RestController::HTTP_OK);
    // }

    // public function delete_keranjang_delete($id)
    // {
    //     $this->response($this->all->delete_keranjang($id), RestController::HTTP_OK);
    // }

    // public function update_qty_keranjang_put($id)
    // {
    //     $qty = $this->put('qty');
    //     $this->response($this->all->update_qty_keranjang($id, $qty), RestController::HTTP_OK);
    // }
}