<?php
defined('BASEPATH') or exit('No direct script access allowed');

class KelolaTentor_admin extends CI_Controller
{
    var $module_js = ['kelola_tentor_admin'];
    var $app_data = [];

    public function __construct()
    {
        parent::__construct();
        $this->_init();
    }

    private function _init()
    {
        $this->app_data['module_js'] = $this->module_js;
    }

    public function index()
    {
        $this->app_data['select'] = $this->data->find('tb_user', array('id_akses' => 'A2'))->result();
        $this->load->view('header_pm');
        $this->load->view('view_tentor_admin', $this->app_data);
        $this->load->view('footer');
        $this->load->view('js-custom', $this->app_data);
    }

    public function get_data()
    {
        $query = [
            'select' => 'a.id_tentor, b.username, a.nama, a.kelas_jenjang, a.mapel', 
            'from' => 'tb_tentor a',
            'join' => [
                'tb_user b, b.ID = a.id_user'
            ]
        ];
        $result = $this->data->get($query)->result();
        echo json_encode($result);
    }

    public function get_data_id()
    {
        $id = $this->input->post('id_tentor');
        $result = $this->data->find('tb_tentor', array('id_tentor' => $id))->result();
        echo json_encode($result);
    }


    public function insert_data()
    {
        $this->form_validation->set_rules('nama', 'nama', 'required|trim');
        $this->form_validation->set_rules('kelas_jenjang', 'kelas_jenjang', 'required|trim');
        $this->form_validation->set_rules('mapel', 'mapel', 'required|trim');

        if ($this->form_validation->run() == false) {
            $response['errors'] = $this->form_validation->error_array();
            if (empty($this->input->post('id_user'))) {
                $response['errors']['id_user'] = "Username harus dipilih";
            }
        } else {
            $nama = $this->input->post('nama');
            $kelas_jenjang = $this->input->post('kelas_jenjang');
            $mapel = $this->input->post('mapel');
            $id_user = $this->input->post('id_user');

            if (empty($this->input->post('id_user'))) {
                $response['errors']['id_user'] = "Username harus dipilih";
            } else {
                $data = array(
                    'id_user' => $id_user,
                    'nama' => $nama,
                    'kelas_jenjang' => $kelas_jenjang,
                    'mapel' => $mapel,
                );
                $this->data->insert('tb_tentor', $data);
                $response['success'] = "Data berhasil ditambahkan";
            }
        }
        echo json_encode($response);
    }

    public function delete_data()
    {
        $id = $this->input->post('id_tentor');
        $where = array('id_tentor' => $id);

        $deleted = $this->data->delete('tb_tentor', $where);
        if ($deleted) {
            $response['success'] = "Data berhasil dihapus";
        } else {
            $response['error'] = "Gagal menghapus data";
        }
        echo json_encode($response);
    }

    public function edit_data()
    {
         $this->form_validation->set_rules('nama', 'nama', 'required|trim');
        $this->form_validation->set_rules('kelas_jenjang', 'kelas_jenjang', 'required|trim');
        $this->form_validation->set_rules('mapel', 'mapel', 'required|trim');

        if ($this->form_validation->run() == false) {
            $response['errors'] = $this->form_validation->error_array();
            if (empty($this->input->post('id_user'))) {
                $response['errors']['id_user'] = "Username harus dipilih";
            }
        } else {
            $id = $this->input->post('id_tentor');
            $nama = $this->input->post('nama');
            $kelas_jenjang = $this->input->post('kelas_jenjang');
            $mapel = $this->input->post('mapel');
            $id_user = $this->input->post('id_user');

            if (empty($this->input->post('id_user'))) {
                $response['errors']['id_user'] = "Username harus dipilih";
            } else {
                $data = array(
                    'id_user' => $id_user,
                    'nama' => $nama,
                    'kelas_jenjang' => $kelas_jenjang,
                    'mapel' => $mapel,
                );

                $where = array('id_tentor' => $id);
                $this->data->update('tb_tentor', $where, $data);
                $response['success'] = "Data berhasil diedit";
            }
        }
        echo json_encode($response);
    }

    public function export_pdf()
	{
        $query = [
            'select' => 'a.id_tentor, b.username, a.nama, a.kelas_jenjang, a.mapel', 
            'from' => 'tb_tentor a',
            'join' => [
                'tb_user b, b.ID = a.id_user'
            ]
        ];
        $data['tentor'] = $this->data->get($query)->result();
		$this->load->library('pdf');
		$this->pdf->setPaper('A4', 'potrait');
		$this->pdf->filename = "laporan-data-tentor.pdf";
		$this->pdf->load_view('laporan_tentor', $data);
	}
 } 