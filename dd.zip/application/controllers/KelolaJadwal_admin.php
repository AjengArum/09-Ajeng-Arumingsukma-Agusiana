<?php
defined('BASEPATH') or exit('No direct script access allowed');

class KelolaJadwal_admin extends CI_Controller
{
    var $module_js = ['kelola_jadwal'];
    var $app_data = [];

    public function __construct()
    {
        parent::__construct();
        $this->_init();
    }

    private function _init()
    {
        $this->app_data['module_js'] = $this->module_js;
    }

    public function index()
    {
        $this->app_data['select'] = $this->data->get_all('tb_tentor')->result();
        $this->load->view('header');
        $this->load->view('view_jadwal', $this->app_data);
        $this->load->view('footer');
        $this->load->view('js-custom', $this->app_data);
    }

    public function get_data()
{
    $query = [
        'select' => 'a.id_jadwal, b.nama as nama_tentor, a.ruang, a.hari, a.jam_mulai, a.jam_berakhir',
        'from' => 'tb_jadwal a',
        'join' => [
            'tb_tentor b, b.id_tentor = a.id_tentor'
        ],
        'order_by' => 'a.id_jadwal'
    ];
    $result = $this->data->get($query)->result();
    echo json_encode($result);
}

    public function get_data_id()
    {
        $id = $this->input->post('id_jadwal');
        $result = $this->data->find('tb_jadwal', array('id_jadwal' => $id))->result();
        echo json_encode($result);
    }



    public function insert_data()
    {
       // $this->form_validation->set_rules('id_jadwal', 'id_jadwal', 'required|trim');
        $this->form_validation->set_rules('ruang', 'ruang', 'required|trim');
        $this->form_validation->set_rules('hari', 'hari', 'required|trim');
        $this->form_validation->set_rules('jam_mulai', 'jam_mulai', 'required|trim');
        $this->form_validation->set_rules('jam_berakhir', 'jam_berakhir', 'required|trim');

        if ($this->form_validation->run() == false) {
            $response['errors'] = $this->form_validation->error_array();
            if (empty($this->input->post('id_tentor'))) {
                $response['errors']['id_tentor'] = "Tentor harus dipilih";
            }
        } else {
            $ruang = $this->input->post('ruang');
            $hari = $this->input->post('hari');;
            $jam_mulai = $this->input->post('jam_mulai');;
            $jam_berakhir = $this->input->post('jam_berakhir');;
            $id_tentor = $this->input->post('id_tentor');

            if (empty($this->input->post('id_tentor'))) {
                $response['errors']['id_tentor'] = "Tentor harus dipilih";
            } else {
                $data = array(
                    'id_tentor' => $id_tentor,
                    'ruang' => $ruang,
                    'hari' => $hari,
                    'jam_mulai' => $jam_mulai,
                    'jam_berakhir' => $jam_berakhir,
                );
                $this->data->insert('tb_jadwal', $data);
                $response['success'] = "Data berhasil ditambahkan";
            }
        }
        echo json_encode($response);
    }

    public function delete_data()
    {
        $id = $this->input->post('id_jadwal');
        $where = array('id_jadwal' => $id);
        
        $deleted = $this->data->delete('tb_jadwal', $where);
        if ($deleted) {
            $response['success'] = "Data berhasil dihapus";
        } else {
            $response['error'] = "Gagal menghapus data";
        }
        echo json_encode($response);
    }

    public function edit_data()
    {
        $this->form_validation->set_rules('id_jadwal_1', 'id_jadwal', 'required|trim');
        $this->form_validation->set_rules('ruang_1', 'ruang', 'required|trim');
        $this->form_validation->set_rules('jadwal_1', 'jadwal', 'required|trim');

        if ($this->form_validation->run() == false) {
            $response['errors'] = $this->form_validation->error_array();
            if (empty($this->input->post('tentor'))) {
                $response['errors']['tentor'] = "Tentor harus dipilih";
            }
        } else {
            $id = $this->input->post('id_jadwal_1');
            $ruang = $this->input->post('ruang_1');
            $jadwal = $this->input->post('jadwal_1');
            $id_tentor = $this->input->post('tentor');

            if (empty($this->input->post('tentor'))) {
                $response['errors']['tentor'] = "Tentor harus dipilih";
            } else {
                $data = array(
                    'id_tentor' => $id_tentor,
                    'ruang' => $ruang,
                    'jadwal' => $jadwal,
                );
                $where = array('id_jadwal' => $id);
                $this->data->update('tb_jadwal', $where, $data);
                $response['success'] = "Data berhasil diedit";
            }
        }
        echo json_encode($response);
    }
}